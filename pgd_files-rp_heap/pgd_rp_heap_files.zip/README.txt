Hey (Ben most likely),

I just wanted to quickly describe the setup of the files that I sent.

I modified the Dijkstra's homework files, so generally they should be very similar to the ones you guys are using.

The only significant difference that I can think of is that I changed some of the function names in the Dijkstra's function.
E.g., I changed remove_min() to extract_min() or something like that.

You should be able to copy "DijkstraRankPairingHeap" from "shortPaths_mod.h" to get a function that properly calls my rp_heap.

I'll do my best to answer any questions that you may have if things are not working.